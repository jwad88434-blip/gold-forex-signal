# GoldForexSignal — independent live-data prototype

Android app (Kotlin + Jetpack Compose) for XAUUSD, EURUSD and GBPUSD.

## Data source
Public biquote REST API documentation: https://biquote.io/docs/
- Latest quote: `GET https://biquote.io/api/{symbol}?allowStale=false`
- Candles: `GET https://biquote.io/api/{symbol}/ohlc?interval=1m|5m&limit=120`
- Public read endpoints require no API key or registration, according to provider docs.
- App refreshes every 10 seconds. Provider recommends WebSocket streaming for production.
- Independent feed; prices/spreads may differ from LiteFinance and are not executable broker quotes.

## Prototype signal logic
- M5 direction: EMA20 vs EMA50.
- M1 confirmation: EMA9 vs EMA21 and last closed candle direction.
- Stop: recent five closed M1 candles' swing low/high.
- Target: 1.5R.
- No order execution. No performance guarantee. Backtest and forward-test first.

## Build APK free with GitHub Actions
1. Create a GitHub repository and upload the CONTENTS of this folder.
2. Open Actions and run `Build Android APK` (or push to main).
3. Download artifact `GoldForexSignal-debug-apk`.
4. Extract `app-debug.apk` and install on Android.

APK is not yet compiled or tested on a physical device. The API/network may be inaccessible from some regions. If fresh valid data is unavailable, the app suppresses signals.
