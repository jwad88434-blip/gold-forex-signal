package com.example.goldforexsignal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2738)
private val Gold = Color(0xFFF2C14E)
private val Muted = Color(0xFF9AA8BA)
private const val API = "https://biquote.io"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Gold)) {
                Dashboard()
            }
        }
    }
}

private data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val isOpen: Boolean)
private data class Quote(val bid: Double, val ask: Double, val mid: Double, val source: String,
                         val state: String, val stale: Boolean, val age: Int, val timestamp: String)
private data class Analysis(val signal: String, val detail: String, val entry: Double?, val stop: Double?,
                            val target: Double?, val trend: String)

private suspend fun getJson(path: String): JSONObject = withContext(Dispatchers.IO) {
    val connection = (URL("$API$path").openConnection() as HttpURLConnection)
    try {
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("Accept", "application/json")
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("HTTP $code")
        JSONObject(body)
    } finally {
        connection.disconnect()
    }
}

private suspend fun fetchQuote(symbol: String): Quote {
    val j = getJson("/api/$symbol?allowStale=false")
    return Quote(
        bid = j.optDouble("bid", Double.NaN),
        ask = j.optDouble("ask", Double.NaN),
        mid = j.optDouble("mid", Double.NaN),
        source = j.optString("source", "منبع مستقل"),
        state = j.optString("marketState", "unknown"),
        stale = j.optBoolean("stale", true),
        age = j.optInt("quoteAgeSeconds", Int.MAX_VALUE),
        timestamp = j.optString("timestamp", "")
    )
}

private suspend fun fetchCandles(symbol: String, interval: String): List<Candle> {
    val j = getJson("/api/$symbol/ohlc?interval=$interval&limit=120")
    val a = j.optJSONArray("bars") ?: JSONArray()
    val out = mutableListOf<Candle>()
    for (i in 0 until a.length()) {
        val c = a.optJSONObject(i) ?: continue
        val candle = Candle(c.optDouble("open", Double.NaN), c.optDouble("high", Double.NaN),
            c.optDouble("low", Double.NaN), c.optDouble("close", Double.NaN), c.optBoolean("isOpen", false))
        if (candle.open.isFinite() && candle.high.isFinite() && candle.low.isFinite() && candle.close.isFinite()) out.add(candle)
    }
    return out.filter { !it.isOpen }.reversed()
}

private fun ema(values: List<Double>, period: Int): Double? {
    if (values.size < period) return null
    val k = 2.0 / (period + 1)
    var result = values.take(period).average()
    for (v in values.drop(period)) result = v * k + result * (1 - k)
    return result
}

private fun analyse(m1: List<Candle>, m5: List<Candle>, quote: Quote): Analysis {
    if (m1.size < 55 || m5.size < 55 || quote.stale || quote.state != "open" || !quote.mid.isFinite()) {
        return Analysis("بدون سیگنال", "داده کافی یا تازه برای تحلیل وجود ندارد.", null, null, null, "نامشخص")
    }
    val closes1 = m1.map { it.close }
    val closes5 = m5.map { it.close }
    val e20 = ema(closes5, 20)!!
    val e50 = ema(closes5, 50)!!
    val e9 = ema(closes1, 9)!!
    val e21 = ema(closes1, 21)!!
    val bullish = e20 > e50
    val bearish = e20 < e50
    val last = m1.last()
    val recent = m1.takeLast(5)
    val entry = quote.ask
    val sellEntry = quote.bid
    return when {
        bullish && e9 > e21 && last.close > last.open -> {
            val sl = recent.minOf { it.low }
            val risk = entry - sl
            if (risk <= 0) Analysis("بدون سیگنال", "فاصله حد ضرر معتبر نیست.", null, null, null, "صعودی")
            else Analysis("خرید (BUY)", "روند M5 صعودی و تأیید M1 مثبت است؛ منتظر تأیید شخصی بمان.", entry, sl, entry + risk * 1.5, "صعودی")
        }
        bearish && e9 < e21 && last.close < last.open -> {
            val sl = recent.maxOf { it.high }
            val risk = sl - sellEntry
            if (risk <= 0) Analysis("بدون سیگنال", "فاصله حد ضرر معتبر نیست.", null, null, null, "نزولی")
            else Analysis("فروش (SELL)", "روند M5 نزولی و تأیید M1 منفی است؛ منتظر تأیید شخصی بمان.", sellEntry, sl, sellEntry - risk * 1.5, "نزولی")
        }
        else -> Analysis("بدون سیگنال", "شرایط هم‌جهتی روند M5 و تأیید کندل M1 کامل نیست.", null, null, null,
            if (bullish) "صعودی" else if (bearish) "نزولی" else "خنثی")
    }
}

@Composable
private fun Dashboard() {
    var symbol by remember { mutableStateOf("XAUUSD") }
    var quote by remember { mutableStateOf<Quote?>(null) }
    var analysis by remember { mutableStateOf(Analysis("در انتظار داده", "در حال دریافت قیمت و کندل‌ها…", null, null, null, "—")) }
    var status by remember { mutableStateOf("در حال اتصال…") }
    var error by remember { mutableStateOf("") }
    var lastUpdate by remember { mutableStateOf("") }

    LaunchedEffect(symbol) {
        quote = null
        analysis = Analysis("در انتظار داده", "در حال دریافت داده واقعی…", null, null, null, "—")
        while (true) {
            try {
                val q = fetchQuote(symbol)
                val m1 = fetchCandles(symbol, "1m")
                val m5 = fetchCandles(symbol, "5m")
                quote = q
                analysis = analyse(m1, m5, q)
                status = if (q.state == "open" && !q.stale && q.age <= 60) "متصل و تازه" else "قیمت قدیمی/بازار بسته"
                error = ""
                lastUpdate = q.timestamp
            } catch (e: Exception) {
                status = "خطا در دریافت داده"
                error = e.message ?: "اتصال برقرار نشد"
                quote = null
                analysis = Analysis("بدون سیگنال", "به علت نبود داده معتبر، سیگنالی صادر نمی‌شود.", null, null, null, "نامشخص")
            }
            delay(10_000)
        }
    }

    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("GOLD / FOREX SIGNAL", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("دستیار تحلیل بازار", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
            Text("نسخه 0.2", color = Muted, fontSize = 12.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("دارایی", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("XAUUSD", "EURUSD", "GBPUSD").forEach { item ->
                        FilterChip(selected = symbol == item, onClick = { symbol = item }, label = { Text(item) })
                    }
                }
                Text("تایم‌فریم تحلیل: M5 روند + M1 تأیید ورود", color = Muted, fontSize = 13.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("وضعیت اتصال داده", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(status, color = if (status == "متصل و تازه") Color(0xFF75D69C) else Color(0xFFFFB4A9), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text("منبع مستقل: biquote · داده عمومی MT5", color = Muted, fontSize = 12.sp)
                quote?.let {
                    Text("قیمت میانی: ${fmt(it.mid)}", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Bid: ${fmt(it.bid)}     Ask: ${fmt(it.ask)}", color = Color.White, fontSize = 13.sp)
                    Text("منبع فید: ${it.source} · عمر داده: ${it.age} ثانیه", color = Muted, fontSize = 11.sp)
                } ?: Text(if (error.isNotBlank()) "جزئیات: $error" else "هنوز قیمت معتبری دریافت نشده است.", color = Muted, fontSize = 13.sp)
                if (lastUpdate.isNotBlank()) Text("آخرین زمان داده: $lastUpdate", color = Muted, fontSize = 10.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("تحلیل و سیگنال", color = Muted)
                Text(analysis.signal, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("جهت روند M5: ${analysis.trend}", color = Color.White)
                Text(analysis.detail, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                analysis.entry?.let {
                    Divider(color = Color(0xFF344256))
                    Text("ورود مرجع: ${fmt(it)}", color = Color.White)
                    Text("حد ضرر پیشنهادی: ${fmt(analysis.stop!!)}", color = Color(0xFFFF8A80))
                    Text("هدف ۱ با نسبت ریسک به بازده ۱:۱٫۵: ${fmt(analysis.target!!)}", color = Color(0xFF75D69C))
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("قواعد تحلیل نسخه 0.2", color = Color.White, fontWeight = FontWeight.Bold)
                Text("• روند M5 با EMA20 و EMA50\n• تأیید M1 با EMA9 و EMA21 و جهت کندل بسته‌شده\n• حد ضرر بر اساس کف/سقف ۵ کندل اخیر M1\n• هدف نمونه با نسبت ۱ به ۱٫۵\n• به‌روزرسانی هر ۱۰ ثانیه", color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
            }
        }
        Text("منبع قیمت مستقل است و الزاماً با نرخ LiteFinance یکسان نیست. داده API ممکن است قطع یا با تأخیر باشد. سیگنال‌ها آزمایشی‌اند، تضمین سود نیستند و سفارش خودکار انجام نمی‌شود.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private fun fmt(v: Double): String = if (!v.isFinite()) "—" else String.format(Locale.US, "%.3f", v)
